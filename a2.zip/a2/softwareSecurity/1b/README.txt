Place the original and fixed version of index.php

Highlight your changes and where you spot vulnerabilities. It will make it easier for you to get part marks.