Member 1:

Name: Patrick Vickery
Student Number: 1000799781
UTORid: vickeryp

Member 2:

Name: Brian Taylor
Student Number: 999207200
UTORid: taylo192
